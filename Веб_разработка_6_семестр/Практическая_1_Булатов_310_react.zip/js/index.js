ReactDOM.render(<div>
    <h1>Привет!</h1>
    <h2>Hello</h2>
    <table>
        <thead>
            <tr>
                <th>Ф.И.О.</th>
                <th>Адрес</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Панова И.И.</td>
                <td>Мира 6, 21</td>
            </tr>
            <tr>
                <td>Мишина В.П.</td>
                <td>Победы 47, 154</td>
            </tr>
            <tr>
                <td>Новикова Е.Н.</td>
                <td>Московская 23-4</td>
            </tr>
        </tbody>
    </table>
    <style>{`
        table {
          border-collapse: collapse;
          width: 30%;
          margin-top: 10px;
        }

        th, td {
          border: 1px solid black;
          padding: 8px;
          text-align: left;
        }

        th {
          
        }
      `}</style>
</div>, document.getElementById("app"))