from django.apps import AppConfig


class TemplatesAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'templates_app'
