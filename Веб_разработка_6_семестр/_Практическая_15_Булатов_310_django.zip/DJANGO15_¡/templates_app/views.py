from django.shortcuts import render

# Create your views here.


def main_view(request):
    context = {
        "user": request.user,
        "fruits": ["Яблоки", "Груши", "Апельсины", "Бананы", "Манго"],
        "users": [
            ["имя", "возраст", "специализация"],
            ["Андрей", "23", "Python"],
            ["Борис", "27", "PHP"],
            ["Владимир", "21", "C++"],
        ],
    }
    return render(request, "main.html", context)


def greeting_view(request):
    context = {"user": request.user}
    return render(request, "greeting.html", context)
