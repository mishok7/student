import { useState, useRef, useEffect } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './App.css';

function App() {
  // Состояния для новостей
  const [articles, setArticles] = useState([
    {
      id: 1,
      title: 'React 3000 выйдет в 2026 году',
      content: 'Команда React анонсировала выход новой версии с улучшенным рендерингом и новыми хуками.',
      category: 'react'
    },
    {
      id: 2,
      title: 'ChatGPT 10: что нового',
      content: 'OpenAI выпустила GPT 10 с нереальными возможностями.',
      category: 'gpt'
    },
    {
      id: 3,
      title: 'JavaScript в 2к25: тренды',
      content: 'Обзор главных трендов в JavaScript на 2025 год.',
      category: 'javascript'  
    },
    {
      id: 4,
      title: 'AGI близок!',
      content: 'Яндекс анонсировали AGI, который перевернет мир.',
      category: 'news'
    },
    {
      id: 5,
      title: 'Оптимизация производительности в React',
      content: 'Лучшие решения для оптимизации React-приложений.',
      category: 'react'
    }
  ]);

  const [activeCategory, setActiveCategory] = useState('all');
  const [activeArticle, setActiveArticle] = useState(null);

  // Фильтрация статей по категории
  const filteredArticles = activeCategory === 'all'
    ? articles
    : articles.filter(article => article.category === activeCategory);

    const CountdownTimer = () => {
      const [timeLeft, setTimeLeft] = useState(60);
      const [isRunning, setIsRunning] = useState(false);
      const intervalRef = useRef(null);
  
      // Запуск таймера
      const startTimer = () => {
        if (!isRunning && timeLeft > 0) {
          setIsRunning(true);
          intervalRef.current = setInterval(() => {
            setTimeLeft(prevTime => {
              if (prevTime <= 1) {
                clearInterval(intervalRef.current);
                setIsRunning(false);
                return 0;
              }
              return prevTime - 1;
            });
          }, 1000);
        }
      };
  
      // Остановка таймера
      const stopTimer = () => {
        clearInterval(intervalRef.current);
        setIsRunning(false);
      };
  
      // Сброс таймера
      const resetTimer = () => {
        clearInterval(intervalRef.current);
        setIsRunning(false);
        setTimeLeft(60);
      };
  
      // Очистка интервала при размонтировании
      useEffect(() => {
        return () => clearInterval(intervalRef.current);
      }, []);
  
      return (
        <div className="mb-4">
          <h3 className="h5 mb-3">Таймер отдыха</h3>
          <div className={`p-3 rounded mb-3 text-center ${timeLeft === 0 ? 'bg-success text-white' : 'bg-light'}`}>
            <p className="display-4 mb-0">
              {timeLeft} <small className="fs-6">сек.</small>
            </p>
            {timeLeft === 0 && <p className="mb-0 mt-2">Время вышло!</p>}
          </div>
          <div className="d-grid gap-2 d-sm-flex justify-content-sm-center">
            {!isRunning ? (
              <button 
                className="btn btn-success px-4" 
                onClick={startTimer}
                disabled={timeLeft === 0}
              >
                <i className="bi bi-play-fill me-2"></i>Старт
              </button>
            ) : (
              <button className="btn btn-danger px-4" onClick={stopTimer}>
                <i className="bi bi-stop-fill me-2"></i>Стоп
              </button>
            )}
            <button className="btn btn-outline-secondary px-4" onClick={resetTimer}>
              <i className="bi bi-arrow-counterclockwise me-2"></i>Сброс
            </button>
          </div>
        </div>
      );
    };

  // Компонент слайдера
  const NewsSlider = () => {
    const [currentSlide, setCurrentSlide] = useState(0);
    const sliderRef = useRef(null);

    const goToSlide = (index) => {
      setCurrentSlide(index);
      const slideWidth = sliderRef.current?.children[0]?.offsetWidth || 0;
      sliderRef.current.style.transform = `translateX(-${index * slideWidth}px)`;
    };

    const nextSlide = () => {
      const next = (currentSlide + 1) % articles.length;
      goToSlide(next);
    };

    const prevSlide = () => {
      const prev = (currentSlide - 1 + articles.length) % articles.length;
      goToSlide(prev);
    };

    useEffect(() => {
      const interval = setInterval(() => {
        nextSlide();
      }, 5000);
      return () => clearInterval(interval);
    }, [currentSlide]);

    return (
      <div className="mb-5">
        <div className="d-flex justify-content-between align-items-center mb-3">
          <h3 className="h5 mb-0">Новостной слайдер</h3>
          <div className="slider-dots">
            {articles.map((_, index) => (
              <button
                key={index}
                className={`btn btn-sm p-0 mx-1 ${index === currentSlide ? 'text-primary' : 'text-muted'}`}
                onClick={() => goToSlide(index)}
              >
                <i className="bi bi-circle-fill"></i>
              </button>
            ))}
          </div>
        </div>

        <div className="position-relative">
          <button
            className="btn btn-sm btn-outline-primary position-absolute start-1 top-50 translate-middle-y z-1"
            onClick={prevSlide}
            style={{ left: '15px' }}
          >
            <i className="bi bi-chevron-left"></i>
          </button>

          <div className="overflow-hidden rounded">
            <div
              className="d-flex transition-all"
              ref={sliderRef}
              style={{ transition: 'transform 0.5s ease' }}
            >
              {articles.map((article) => (
                <div
                  key={article.id}
                  className="flex-shrink-0 w-100 bg-light p-4"
                  style={{ minHeight: '200px' }}
                >
                  <h4 className="h6 text-primary">{article.title}</h4>
                  <p className="mb-0">{article.content}</p>
                </div>
              ))}
            </div>
          </div>

          <button
            className="btn btn-sm btn-outline-primary position-absolute end-1 top-50 translate-middle-y z-1"
            onClick={nextSlide}
            style={{ right: '15px' }}
          >
            <i className="bi bi-chevron-right"></i>
          </button>
        </div>
      </div>
    );
  };

  return (
    <div className="container py-4">
      <header className="text-center mb-5">
        <h1 className="display-4 fw-bold text-primary mb-3">
          <i className="bi bi-newspaper me-3"></i>
          Новости программиста
        </h1>
        <p className="lead text-muted">
          Самые свежие материалы для разработчиков на одном ресурсе
        </p>
      </header>
    
      <div className="row">
        {/* Боковая панель */}
        <div className="col-lg-3 mb-4 mb-lg-0">
          <div className="card shadow-sm mb-4">
            <div className="card-body">
              <CountdownTimer />
            </div>
          </div>

          <div className="card shadow-sm">
            <div className="card-body">
              <h3 className="h5 mb-3">
                <i className="bi bi-tags me-2"></i>
                Категории
              </h3>
              <div className="d-grid gap-2">
                <button
                  className={`btn ${activeCategory === 'all' ? 'btn-primary' : 'btn-outline-primary'} text-start`}
                  onClick={() => setActiveCategory('all')}
                >
                  <i className="bi bi-collection me-2"></i>
                  Все статьи
                </button>
                {['react', 'javascript', 'gpt', 'news'].map(cat => (
                  <button
                    key={cat}
                    className={`btn ${activeCategory === cat ? 'btn-primary' : 'btn-outline-primary'} text-start`}
                    onClick={() => setActiveCategory(cat)}
                  >
                    <i className={`bi bi-${getCategoryIcon(cat)} me-2`}></i>
                    {getCategoryName(cat)}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Основной контент */}
        <div className="col-lg-9">
          <div className="card shadow-sm mb-4">
            <div className="card-body">
              <NewsSlider />
            </div>
          </div>

          <div className="card shadow-sm">
            <div className="card-body">
              <div className="d-flex justify-content-between align-items-center mb-4">
                <h2 className="h4 mb-0">
                  <i className="bi bi-list-ul me-2"></i>
                  {activeCategory === 'all' ? 'Все статьи' : `Статьи: ${getCategoryName(activeCategory)}`}
                </h2>
                <span className="badge bg-primary">
                  {filteredArticles.length} статей
                </span>
              </div>

              <div className="list-group">
                {filteredArticles.map(article => (
                  <div
                    key={article.id}
                    className={`list-group-item list-group-item-action ${activeArticle === article.id ? 'active' : ''}`}
                    onClick={() => setActiveArticle(activeArticle === article.id ? null : article.id)}
                  >
                    <div className="d-flex justify-content-between align-items-start">
                      <h3 className="h5 mb-1">{article.title}</h3>
                      <span className="badge bg-secondary bg-opacity-10 text-secondary">
                        {article.category}
                      </span>
                    </div>
                    {activeArticle === article.id && (
                      <p className="mb-0 mt-2">{article.content}</p>
                    )}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// Вспомогательные функции
function getCategoryName(category) {
  const names = {
    react: 'React',
    javascript: 'JavaScript',
    typescript: 'Gpt',
    news: 'Новости'
  };
  return names[category] || category;
}

function getCategoryIcon(category) {
  const icons = {
    react: 'react',
    javascript: 'filetype-js',
    typescript: 'filetype-ts',
    news: 'newspaper'
  };
  return icons[category] || 'tag';
}

export default App;