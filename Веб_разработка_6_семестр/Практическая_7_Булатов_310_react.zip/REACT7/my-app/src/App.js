import { useState } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  return (
    <Router>
      <Navigation />
      <div className="container mt-4">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/journal" element={<JournalPage />} />
        </Routes>
      </div>
    </Router>
  );
}

function Navigation() {
  return (
    <nav className="navbar navbar-expand-lg navbar-dark bg-primary">
      <div className="container-fluid">
        <Link className="navbar-brand" to="/">Журнал посещаемости</Link>
        <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav">
            <li className="nav-item">
              <Link className="nav-link" to="/">Главная</Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/journal">Журнал</Link>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
}

function HomePage() {
  return (
    <div className="card">
      <div className="card-body">
        <h1 className="card-title">Журнал посещаемости</h1>
        <p className="card-text">Система для учета посещаемости студентов</p>
        <Link to="/journal" className="btn btn-primary">Перейти к журналу</Link>
      </div>
    </div>
  );
}

function JournalPage() {
  const [students, setStudents] = useState([
    { id: 1, name: 'Булатов Михаил Владимирович', selected: false, attendance: ['Н', 'Н', 'П', 'Н', 'Н', 'Н'] },
    { id: 2, name: 'Сопов Матвей Андреевич', selected: false, attendance: ['Н', 'ОП', 'П', 'Н', 'Н', 'П'] },
    { id: 3, name: 'Бикбаев Ильгис Русланович', selected: false, attendance: ['Н', 'П', 'Н', 'Н', 'Н', 'Н'] },
  ]);
  
  const [filter, setFilter] = useState('');
  const [newStudentName, setNewStudentName] = useState('');

  // Даты занятий из макета
  const classDates = ['05.05.2025', '06.05.2025', '07.05.2025', '08.05.2025', '09.05.2025', '10.05.2025'];
  const classTimes = ['8:30-10:00', '8:30-10:00', '8:30-10:00', '8:30-10:00', '8:30-10:00', '8:30-10:00'];

  const addStudent = () => {
    if (newStudentName.trim()) {
      const newStudent = {
        id: Date.now(),
        name: newStudentName,
        selected: false,
        attendance: Array(classDates.length).fill('Н')
      };
      setStudents([...students, newStudent]);
      setNewStudentName('');
    }
  };

  const deleteSelected = () => {
    setStudents(students.filter(student => !student.selected));
  };

  const toggleStudent = (id) => {
    setStudents(students.map(student => 
      student.id === id ? { ...student, selected: !student.selected } : student
    ));
  };

  const updateAttendance = (studentId, classIndex, value) => {
    setStudents(students.map(student => {
      if (student.id === studentId) {
        const newAttendance = [...student.attendance];
        newAttendance[classIndex] = value;
        return { ...student, attendance: newAttendance };
      }
      return student;
    }));
  };

  const filteredStudents = students.filter(student =>
    student.name.toLowerCase().includes(filter.toLowerCase())
  );

  return (
    <div className="card">
      <div className="card-body">
        <h2 className="card-title mb-4">Журнал по дисциплине</h2>
        
        <div className="row mb-4">
          <div className="col-md-6">
            <label className="form-label">Показать занятия за период:</label>
            <div className="d-flex gap-3">
              <div>
                <div className="text-muted">C: 05 мая 2025</div>
                <div className="text-muted">По: 10 мая 2025</div>
              </div>
            </div>
          </div>
          
          <div className="col-md-6">
            <label className="form-label">Виды занятий:</label>
            <select className="form-select">
              <option>Выбрать...</option>
              <option>Лекции</option>
              <option>Практические</option>
            </select>
          </div>
        </div>
        
        <div className="mb-4">
          <div><strong>Группа:</strong> ИСП-310</div>
          <div><strong>Дисциплина:</strong> Веб-разработка</div>Ы
        </div>

        <div className="row mb-4 g-3">
          <div className="col-md-4">
            <input
              type="text"
              className="form-control"
              placeholder="Фильтр по имени"
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
            />
          </div>
          <div className="col-md-4">
            <input
              type="text"
              className="form-control"
              placeholder="Новый студент"
              value={newStudentName}
              onChange={(e) => setNewStudentName(e.target.value)}
            />
          </div>
          <div className="col-md-2">
            <button className="btn btn-success w-100" onClick={addStudent}>Добавить</button>
          </div>
          <div className="col-md-2">
            <button className="btn btn-danger w-100" onClick={deleteSelected}>Удалить выбранных</button>
          </div>
        </div>

        <div className="table-responsive">
          <table className="table table-bordered table-hover">
            <thead className="table-light">
              <tr>
                <th style={{width: '50px'}}>№</th>
                <th style={{width: '250px'}}>ФИО</th>
                {classDates.map((date, index) => (
                  <th key={index} style={{width: '120px', textAlign: 'center'}}>
                    <div>{date}</div>
                    <div className="small text-muted">{classTimes[index]}</div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {filteredStudents.map((student, index) => (
                <tr 
                  key={student.id}
                  className={student.selected ? 'table-primary' : ''}
                  onClick={() => toggleStudent(student.id)}
                  style={{cursor: 'pointer'}}
                >
                  <td>{students.length - index}</td>
                  <td>{student.name}</td>
                  {student.attendance.map((status, classIndex) => (
                    <td key={classIndex} style={{textAlign: 'center'}}>
                      <select 
                        value={status} 
                        onChange={(e) => updateAttendance(student.id, classIndex, e.target.value)}
                        onClick={(e) => e.stopPropagation()}
                        className="form-select form-select-sm"
                      >
                        <option value="Н">Н</option>
                        <option value="П">П</option>
                        <option value="ОП">ОП</option>
                      </select>
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default App;