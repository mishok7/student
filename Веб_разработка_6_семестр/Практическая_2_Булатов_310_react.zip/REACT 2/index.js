
// Создаем компонент "Счетчик"
class Counter extends React.Component {
    // Конструктор, вызывается один раз при создании компонента
    constructor(props) {
        super(props); // Всегда вызываем super(props) в конструкторе
        this.state = { count: 0 }; // Начальное состояние: счетчик равен 0

        // Привязываем методы к контексту, чтобы this работал правильно
        this.increment = this.increment.bind(this);
        this.decrement = this.decrement.bind(this);
    }

    // Метод для увеличения счетчика
    increment() {
        // Обновляем состояние с помощью setState
        this.setState({ count: this.state.count + 1 });
    }

    // Метод для уменьшения счетчика
    decrement() {
        // Обновляем состояние с помощью setState
        this.setState({ count: this.state.count - 1 });
    }

    // Метод, определяющий, что отображать на экране
    render() {
        return (
            React.createElement('div', null, // Создаем div-контейнер
                React.createElement('h1', null, 'Счетчик: ' + this.state.count), // Выводим текущее значение счетчика
                React.createElement('button', { onClick: this.increment }, '+1'), // Кнопка "+1"
                React.createElement('button', { onClick: this.decrement }, '-1')  // Кнопка "-1"
            )
        );
    }
}

ReactDOM.render(React.createElement(Counter), document.getElementById('app'));