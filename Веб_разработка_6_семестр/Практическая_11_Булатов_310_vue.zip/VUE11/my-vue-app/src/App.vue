<template>
  <div class="counter">
    <h1 class="counter-value">{{ count }}</h1>
    <div class="buttons">
      <button class="btn decrement" @click="decrement">-1</button>
      <button class="btn increment" @click="increment">+1</button>
      <button 
        class="btn reset"
        @mouseover="reset"
        @focus="reset"
      >
        Reset counter
      </button>
    </div>
  </div>
</template>

<script>
export default {
  name: 'UniqueCounter',
  data() {
    return {
      count: 0
    }
  },
  methods: {
    increment() {
      this.count++
    },
    decrement() {
      this.count--
    },
    reset() {
      this.count = 0
    }
  }
}
</script>

<style scoped>
.counter {
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
  text-align: center;
  max-width: 320px;
  margin: 0 auto;
  padding: 2.5rem;
  border: 2px solid #6a5acd;
  border-radius: 16px;
  box-shadow: 0 4px 15px rgba(106, 90, 205, 0.2);
  background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
  transform-style: preserve-3d;
  perspective: 500px;
}

.counter-value {
  font-size: 3.5rem;
  margin: 0 0 2rem;
  color: #6a5acd;
  text-shadow: 1px 1px 2px rgba(0,0,0,0.1);
  font-weight: 700;
  letter-spacing: 1px;
}

.buttons {
  display: flex;
  gap: 0.8rem;
  justify-content: center;
  flex-wrap: wrap;
}

.btn {
  padding: 0.7rem 1.4rem;
  font-size: 1.1rem;
  cursor: pointer;
  border: none;
  border-radius: 8px;
  font-weight: 600;
  transition: all 0.3s cubic-bezier(0.25, 0.8, 0.25, 1);
  box-shadow: 0 2px 5px rgba(0,0,0,0.1);
  min-width: 80px;
}

.btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 8px rgba(0,0,0,0.15);
}

.btn:active {
  transform: translateY(0);
}

.decrement {
  background-color: #ff6b6b;
  color: white;
}

.decrement:hover {
  background-color: #ff5252;
}

.increment {
  background-color: #51cf66;
  color: white;
}

.increment:hover {
  background-color: #40c057;
}

.reset {
  background-color: #fcc419;
  color: #343a40;
  flex-basis: 100%;
  margin-top: 0.5rem;
}

.reset:hover,
.reset:focus {
  background-color: #ffd43b;
  color: #212529;
}

/* Анимация при изменении значения */
.counter-value {
  transition: all 0.3s ease;
}

.counter-value.updating {
  transform: scale(1.1);
  color: #4dabf7;
}
</style>