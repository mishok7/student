// Классовый компонент
class Header extends React.Component {
    render() {
        const { brandName = "Книжный Маркет" } = this.props;
        return (
            <nav className="navbar navbar-expand-lg navbar-light bg-light">
                <div className="container-fluid">
                    <a className="navbar-brand" href="#">
                        <i className="fas fa-book-open me-2"></i>
                        {brandName}
                    </a>
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse justify-content-between" id="navbarNav">
                        <div className="mx-auto">
                            <ul className="navbar-nav">
                                {this.props.menuItems.map((item, index) => (
                                    <li className="nav-item" key={index}>
                                        <a className={`nav-link ${item.active ? 'active' : ''}`} href={item.link}>
                                            <i className={`fas ${item.icon} me-1`}></i>{item.text}
                                        </a>
                                    </li>
                                ))}
                            </ul>
                        </div>
                        <button className="btn btn-cart">
                            <i className="fas fa-shopping-cart me-2"></i>
                            Корзина
                        </button>
                    </div>
                </div>
            </nav>
        );
    }
}

const books = [
    {
        id: 1,
        title: "Мастер и Маргарита",
        author: "Михаил Булгаков",
        price: 890,
        image: "https://basket-05.wbbasket.ru/vol837/part83748/83748710/images/big/1.webp"
    },
    {
        id: 2,
        title: "Преступление и наказание",
        author: "Фёдор Достоевский",
        price: 750,
        image: "https://basket-01.wbbasket.ru/vol74/part7420/7420379/images/big/1.webp"
    },
    {
        id: 3,
        title: "Война и мир",
        author: "Лев Толстой",
        price: 1200,
        image: "https://basket-10.wbbasket.ru/vol1567/part156727/156727161/images/big/1.webp"
    },
    {
        id: 4,
        title: "Евгений Онегин",
        author: "Александр Пушкин",
        price: 620,
        image: "https://basket-03.wbbasket.ru/vol288/part28887/28887753/images/big/1.webp"
    },
    {
        id: 5,
        title: "Отцы и дети",
        author: "Иван Тургенев",
        price: 580,
        image: "https://basket-22.wbbasket.ru/vol3748/part374836/374836320/images/big/1.webp"
    },
    {
        id: 6,
        title: "Герой нашего времени",
        author: "Михаил Лермонтов",
        price: 550,
        image: "https://basket-01.wbbasket.ru/vol22/part2260/2260521/images/big/1.webp"
    },
    {
        id: 7,
        title: "Мёртвые души",
        author: "Николай Гоголь",
        price: 680,
        image: "https://basket-01.wbbasket.ru/vol22/part2230/2230453/images/big/1.webp"
    },
    {
        id: 8,
        title: "Анна Каренина",
        author: "Лев Толстой",
        price: 920,
        image: "https://basket-22.wbbasket.ru/vol3892/part389262/389262484/images/big/1.webp"
    }
];

// Стрелочный компонент
const MainContent = ({ books = [], gridCols = 4 }) => {
    return (
        <main className="text-center mt-4">
            <h1 className="main-header">МИФЫ И ЛЕГЕНДЫ</h1>
            <div className="container">
                <h2 className="section-title">ТОП-8: что сейчас читают</h2>
                <div className="row">
                    {books.map((book, index) => (
                        <div className={`col-md-${12 / gridCols} mb-4`} key={book.id}>
                            <BookCard {...book} />
                        </div>
                    ))}
                </div>
            </div>
        </main>
    );
};

// Функциональный компонент
function BookCard({ title, author, price, image, onAddToCart = () => { } }) {
    return (
        <div className="card">
            <img src={image} className="card-img-top" alt={title} style={{ height: '370px', objectFit: 'cover' }} />
            <div className="card-body d-flex flex-column">
                <h5 className="card-title">{title}</h5>
                <p className="card-text">{author}</p>
                <p className="price">Цена: {price} Р.</p>
                <button className="btn btn-custom mt-auto" onClick={onAddToCart}>
                    <i className="fas fa-shopping-cart me-2"></i>В корзину
                </button>
            </div>
        </div>
    );
}

const Footer = ({ year = new Date().getFullYear(), companyName = "Книжный Маркет" }) => (
    <footer className="bg-light text-center p-4 mt-4">
        <p>&copy; {year} {companyName}. Все права защищены.</p>
    </footer>
);

const App = () => {
    const menuItems = [
        { text: "Книги", icon: "fa-book", link: "#", active: true },
        { text: "Курсы", icon: "fa-graduation-cap", link: "#", active: false },
        { text: "Блог", icon: "fa-blog", link: "#", active: false }
    ];

    return (
        <div>
            <Header menuItems={menuItems} brandName="Книжный Маркет" />
            <MainContent books={books} gridCols={4} />
            <Footer />
        </div>
    );
};

ReactDOM.render(<App />, document.getElementById('app'));