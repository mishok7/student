import React, { useState } from 'react';
import './Menu.css';

const Menu = () => {
    const [activeItem, setActiveItem] = useState(null);

    const menuItems = [
        {
            id: 1,
            title: 'Карбонара',
            description: 'Спагетти, бекон, сливки, яйцо, сыр пармезан',
            price: '590 ₽',
            weight: '350 г',
            calories: '840 ккал',
            image: 'https://via.placeholder.com/150'
        },
        {
            id: 2,
            title: 'Цезарь с курицей',
            description: 'Салат романо, куриное филе, гренки, помидоры черри, сыр пармезан, соус цезарь',
            price: '520 ₽',
            weight: '270 г',
            calories: '450 ккал',
            image: 'https://via.placeholder.com/150'
        },
        {
            id: 3,
            title: 'Борщ',
            description: 'Свекла, капуста, картофель, морковь, лук, говядина, сметана',
            price: '450 ₽',
            weight: '400 г',
            calories: '320 ккал',
            image: 'https://via.placeholder.com/150'
        },
        {
            id: 4,
            title: 'Стейк из говядины',
            description: 'Говяжья вырезка, картофельное пюре, овощи гриль, соус деми-гляс',
            price: '890 ₽',
            weight: '350 г',
            calories: '620 ккал',
            image: 'https://via.placeholder.com/150'
        },
        {
            id: 5,
            title: 'Тирамису',
            description: 'Савоярди, маскарпоне, кофе, какао, ликер',
            price: '380 ₽',
            weight: '150 г',
            calories: '420 ккал',
            image: 'https://via.placeholder.com/150'
        },
        {
            id: 6,
            title: 'Греческий салат',
            description: 'Свежие овощи, оливки, сыр фета, оливковое масло',
            price: '420 ₽',
            weight: '250 г',
            calories: '280 ккал',
            image: 'https://via.placeholder.com/150'
        }
    ];

    const handleItemClick = (id) => {
        if (activeItem === id) {
            setActiveItem(null);
        } else {
            setActiveItem(id);
        }
    };

    return (
        <div className="menu-container">
            <h1 className="menu-title">Наше меню</h1>
            <div className="menu-items">
                {menuItems.map((item) => (
                    <div
                        key={item.id}
                        className={`menu-item ${activeItem === item.id ? 'active' : ''}`}
                        onClick={() => handleItemClick(item.id)}
                    >
                        <div className="menu-item-header">
                            <img src={item.image} alt={item.title} className="menu-item-image" />
                            <h2 className="menu-item-title">{item.title}</h2>
                        </div>
                        {activeItem === item.id && (
                            <div className="menu-item-details">
                                <p className="menu-item-description">{item.description}</p>
                                <div className="menu-item-info">
                                    <span className="menu-item-weight">{item.weight}</span>
                                    <span className="menu-item-calories">{item.calories}</span>
                                </div>
                                <p className="menu-item-price">{item.price}</p>
                            </div>
                        )}
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Menu; 