import React, { useState } from 'react';
import './App.css';

function App() {
  const [activeItem, setActiveItem] = useState(null);

  const categories = [
    { id: 'all', name: 'Все меню' },
    { id: 'main', name: 'Основные блюда' },
    { id: 'salads', name: 'Салаты' },
    { id: 'soups', name: 'Супы' },
    { id: 'desserts', name: 'Десерты' }
  ];

  const menuItems = [
    {
      id: 1,
      title: 'Карбонара',
      description: 'Спагетти, бекон, сливки, яйцо, сыр пармезан, соус карбонара',
      price: '590 ₽',
      weight: '350 г',
      calories: '840 ккал',
      image: 'https://i.pinimg.com/736x/6b/18/61/6b186123efac9e1c476b3060ae3f8799.jpg',
      category: 'main'
    },
    {
      id: 2,
      title: 'Цезарь с курицей',
      description: 'Салат романо, куриное филе, гренки, помидоры черри, сыр пармезан, соус',
      price: '520 ₽',
      weight: '270 г',
      calories: '450 ккал',
      image: 'https://i.pinimg.com/736x/6d/3d/0a/6d3d0a80faf5c2bb113893beda1df520.jpg',
      category: 'salads'
    },
    {
      id: 3,
      title: 'Борщ',
      description: 'Свекла, капуста, картофель, морковь, лук, говядина, сметана',
      price: '450 ₽',
      weight: '400 г',
      calories: '320 ккал',
      image: 'https://i.pinimg.com/736x/d0/18/7e/d0187ee4991d3f183f602d9e7f4dfbc0.jpg',
      category: 'soups'
    },
    {
      id: 4,
      title: 'Стейк из говядины',
      description: 'Говяжья вырезка, картофельное пюре, овощи гриль, соус деми-гляс',
      price: '890 ₽',
      weight: '350 г',
      calories: '620 ккал',
      image: 'https://i.pinimg.com/736x/4c/44/40/4c44402de11a9b2a374663de98dd0ff8.jpg',
      category: 'main'
    },
    {
      id: 5,
      title: 'Тирамису',
      description: 'Савоярди, маскарпоне, кофе, какао, ликер, шоколад, крем',
      price: '380 ₽',
      weight: '150 г',
      calories: '420 ккал',
      image: 'https://i.pinimg.com/736x/2c/4d/dc/2c4ddcf9882f17bd7975019ba45ec3d7.jpg',
      category: 'desserts'
    },
    {
      id: 6,
      title: 'Греческий салат',
      description: 'Свежие овощи, оливки, сыр фета, оливковое масло, лимон',
      price: '420 ₽',
      weight: '250 г',
      calories: '280 ккал',
      image: 'https://i.pinimg.com/736x/74/93/1e/74931e2af7aebb027a38f1349b6c170c.jpg',
      category: 'salads'
    },
    {
      id: 7,
      title: 'Паста с морепродуктами',
      description: 'Паста, креветки, мидии, кальмары, томаты, базилик, чеснок',
      price: '650 ₽',
      weight: '380 г',
      calories: '520 ккал',
      image: 'https://i.pinimg.com/736x/c8/e6/70/c8e67058c1f1f767b86c17f4de033e7b.jpg',
      category: 'main'
    },
    {
      id: 8,
      title: 'Чизкейк Нью-Йорк',
      description: 'Сливочный сыр, сливки, яйца, сахар, ванильный экстракт, печенье',
      price: '350 ₽',
      weight: '120 г',
      calories: '350 ккал',
      image: 'https://i.pinimg.com/736x/02/0b/28/020b2879912f2fca706977372ecfd189.jpg',
      category: 'desserts'
    }
  ];

  const handleItemClick = (id) => {
    if (activeItem === id) {
      setActiveItem(null);
    } else {
      setActiveItem(id);
    }
  };

  return (
    <div className="App">
      <header className="header">
        <div className="header-container">
          <div className="logo">Ресторан</div>
          <nav className="navigation">
            <ul className="nav-menu">
              {categories.map(category => (
                <li
                  key={category.id}
                  className="nav-item"
                >
                  {category.name}
                </li>
              ))}
            </ul>
          </nav>
        </div>
      </header>

      <div className="menu-container">
        <h1 className="menu-title">Наше меню</h1>
        <div className="menu-items">
          {menuItems.map((item) => (
            <div
              key={item.id}
              className={`menu-item ${activeItem === item.id ? 'active' : ''}`}
              onClick={() => handleItemClick(item.id)}
            >
              <div className="menu-item-image-container">
                <img src={item.image} alt={item.title} className="menu-item-image" />
              </div>
              <div className="menu-item-content">
                <h2 className="menu-item-title">{item.title}</h2>
                <div className="menu-item-weight-price">
                  <span className="menu-item-weight">{item.weight}</span>
                  <span className="menu-item-price">{item.price}</span>
                </div>
                {activeItem === item.id && (
                  <div className="menu-item-details">
                    <p className="menu-item-description">{item.description}</p>
                    <div className="menu-item-info">
                      <span className="menu-item-calories">{item.calories}</span>
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>

      <footer className="footer">
        <div className="footer-container">
          <div className="footer-info">
            <p>© 2025 Ресторан</p>
            <p>Адрес: ул. Московская 1, г. Москва</p>
            <p>Телефон: +7 (999) 999-99-99</p>
          </div>
          <div className="footer-hours">
            <p>Часы работы:</p>
            <p>Пн-Пт: 10:00 - 22:00</p>
            <p>Сб-Вс: 11:00 - 23:00</p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;
