
const name = "Булатов Михаил Владимирович";
const age = 19;

function getGreeting(name) {
    return "Привет, " + name + "!";
}

const myStyle = {
    fontSize: '20px',
    textAlign: 'center'
};

const element = (
    <div style={myStyle}>
        <h1>{getGreeting(name)}</h1>
        <p>Возраст: {age + 2}</p>
        <p>ФИО: {name.toUpperCase()}</p>
    </div>
);



const calculatorStyle = {
    display: 'grid',
    gridTemplateColumns: 'repeat(4, 1fr)',
    gap: '10px',
    maxWidth: '280px',
    margin: '20px auto',
    backgroundColor: '#333',
    padding: '20px',
    borderRadius: '10px',
  };
  
  const buttonStyle = {
    padding: '20px',
    fontSize: '20px',
    backgroundColor: '#444',
    color: 'white',
    border: 'none',
    borderRadius: '5px',
  };
  
  const resultStyle = {
    gridColumn: 'span 4',
    padding: '20px',
    fontSize: '24px',
    color: 'white',
    backgroundColor: '#222',
    textAlign: 'right',
    borderRadius: '5px',
  };
  
  function Calculator() {
    const [result, setResult] = React.useState("0");
    const [expression, setExpression] = React.useState(""); // Храним полную строку выражения
  
    const handleButtonClick = (value) => {
      switch (value) {
        case 'C':
          setResult("0");
          setExpression("");
          break;
        case '=':
          try {
            // Используем eval для вычисления
            // Заменяем символы для корректной работы eval
            const calculatedResult = eval(expression.replace('÷', '/').replace('×', '*').replace(',', '.').replace('−', '-'));
            setResult(calculatedResult.toString());
            setExpression(calculatedResult.toString()); // Сохраняем результат как новое выражение
          } catch (error) {
            setResult("Error");
            setExpression("");
          }
          break;
        case '()': 
          break;
        case '%': 
          break;
        case '.':
          if (result.includes(".")) {
              return;
          }
          setResult(prevResult => prevResult + value);
          setExpression(prevExpression => prevExpression + value)
          break;
        default:
          setResult(prevResult => prevResult === "0" ? value : prevResult + value);
          setExpression(prevExpression => prevExpression + value);
      }
    };

    return (
        <div style={calculatorStyle}>
          <div style={resultStyle}>{result}</div>
          {['C', '()', '%', '÷', '7', '8', '9', '×', '4', '5', '6', '−', '1', '2', '3', '+', '.', '0', ',', '='].map((btn, index) => (
            <button
              key={index}
              style={buttonStyle}
              onClick={() => handleButtonClick(btn)}
            >
              {btn}
            </button>
          ))}
        </div>
      );
    }
  
  const appElement = (
    <div>
      <Calculator />
    </div>
  );

  const persons = [
    {
        id: 1,
        firstName: "Иван",
        lastName: "Иванов",
        profession: "Программист",
        birthYear: 1985,
        country: "Россия",
        photo: "https://i.pinimg.com/736x/b6/8f/f7/b68ff72e51405fa63f5db9b05f7e5410.jpg",
    },
    {
        id: 2,
        firstName: "Мария",
        lastName: "Петрова",
        profession: "Врач",
        birthYear: 1990,
        country: "Россия",
        photo: "https://cdn1.flamp.ru/eb7027716b4199eb5d8c8d1a52a73566.jpg",
    },
    {
        id: 3,
        firstName: "Джейсон",
        lastName: "Стэйтем",
        profession: "Инженер",
        birthYear: 1980,
        country: "США",
        photo: "https://i.pinimg.com/736x/20/3f/fc/203ffcb632b89319d71b2283a431725a.jpg",
    },
    {
        id: 4,
        firstName: "Марго",
        lastName: "Робби",
        profession: "Учитель",
        birthYear: 1995,
        country: "Россия",
        photo: "https://static.insales-cdn.com/r/QOw-gXe_LGk/rs:fit:800:800:1/plain/images/collections/1/2661/93416037/margo-robbi-49-foto-48.jpg@webp",
    },
    {
        id: 5,
        firstName: "Доминик",
        lastName: "Торетто",
        profession: "Повар",
        birthYear: 1975,
        country: "Франция",
        photo: "https://yt3.googleusercontent.com/ytc/AIdro_kEufIatcTHgrHo5wGXfQVg-drTybEBLe4rRyw2CwjggA=s900-c-k-c0x00ffffff-no-rj",
    },
];

class PersonList extends React.Component {
    constructor(props) {
        super(props);
        this.state = {
            persons: props.persons,
            sortBy: 'lastName',
            filterProfession: '',
            showPhotos: true,
        };

        this.handleSortChange = this.handleSortChange.bind(this);
        this.handleFilterChange = this.handleFilterChange.bind(this);
        this.handleTogglePhotos = this.handleTogglePhotos.bind(this);
    }

    handleSortChange(event) {
        this.setState({ sortBy: event.target.value });
    }

    handleFilterChange(event) {
        this.setState({ filterProfession: event.target.value });
    }

    handleTogglePhotos() {
        this.setState({ showPhotos: !this.state.showPhotos });
    }

    getSortedAndFilteredPersons() {
        let filteredPersons = this.state.persons;

        if (this.state.filterProfession) {
            filteredPersons = filteredPersons.filter(person =>
                person.profession.toLowerCase().includes(this.state.filterProfession.toLowerCase())
            );
        }

        const sortBy = this.state.sortBy;
        filteredPersons.sort((a, b) => {
            if (sortBy === 'lastName') {
                return a.lastName.localeCompare(b.lastName);
            } else if (sortBy === 'birthYear') {
                return a.birthYear - b.birthYear;
            } else if (sortBy === 'profession') {
                return a.profession.localeCompare(b.profession);
            }
            return 0;
        });

        return filteredPersons;
    }


    render() {
        const sortedAndFilteredPersons = this.getSortedAndFilteredPersons();

        //Статистика по странам
        const countryCounts = {};
        this.state.persons.forEach(person => {
          countryCounts[person.country] = (countryCounts[person.country] || 0) + 1;
        });
        const countryStats = Object.entries(countryCounts).map(([country, count]) => (
            <li key={country} className="list-group-item">{country}: {count}</li>
        ));


        return (
            <div className="container">
                <h1>Справочник Персонала</h1>

                <div className="mb-3">
                    <label htmlFor="sortBy" className="form-label">Сортировать по:</label>
                    <select id="sortBy" className="form-control" value={this.state.sortBy} onChange={this.handleSortChange}>
                        <option value="lastName">Фамилии</option>
                        <option value="birthYear">Году рождения</option>
                        <option value="profession">Профессии</option>
                    </select>
                </div>

                <div className="mb-3">
                    <label htmlFor="filterProfession" className="form-label">Фильтр по профессии:</label>
                    <input
                        type="text"
                        id="filterProfession"
                        className="form-control"
                        value={this.state.filterProfession}
                        onChange={this.handleFilterChange}
                    />
                </div>

                <div className="form-check mb-3">
                    <input
                        type="checkbox"
                        className="form-check-input"
                        id="showPhotos"
                        checked={this.state.showPhotos}
                        onChange={this.handleTogglePhotos}
                    />
                    <label className="form-check-label" htmlFor="showPhotos">
                        Отображать фотографии
                    </label>
                </div>

                <ul className="list-group">
                    {sortedAndFilteredPersons.map(person => (
                        <li key={person.id} className="list-group-item">
                            {this.state.showPhotos && (
                                <img src={person.photo} alt={person.firstName + " " + person.lastName} className="person-image" />
                            )}
                            {person.lastName} {person.firstName} - {person.profession} ({person.birthYear}), Страна: {person.country}
                        </li>
                    ))}
                </ul>

                <h2 className="mt-4">Статистика по странам</h2>
                <ul className="list-group">
                    {countryStats}
                </ul>
            </div>
        );
    }
}

// Рендерим и старый элемент, и новый компонент
ReactDOM.render(
    <div>
        {element}
        {appElement}
        <PersonList persons={persons} />
    </div>,
    document.getElementById('app')
);